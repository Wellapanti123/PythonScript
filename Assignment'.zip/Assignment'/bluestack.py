from selenium import webdriver
import os

driver = webdriver.Firefox()
driver.get("bluestacks.com")
assert "Python" in driver.title
elem = driver.find_element_by_xpath("//div(@class='download-buttons')/a")
elem.click()
downloads = "c:/Downloads";
os.system("cd"+ downloads);
os.system('/install = bluestack.exe /s');
time = os.system('timeit timeit -?');
assert "time is equal to "+ time
driver.close()